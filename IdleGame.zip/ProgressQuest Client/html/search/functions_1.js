var searchData=
[
  ['sqlexecutor_15',['SqlExecutor',['../class_progress_quest___client_1_1_sql_executor.html#a7ff13ae775e554b380067f6e8cdc83a0',1,'ProgressQuest_Client.SqlExecutor.SqlExecutor()'],['../class_progress_quest___client_1_1_sql_executor.html#ad730e702e5199cfefd7d2ca23aff253d',1,'ProgressQuest_Client.SqlExecutor.SqlExecutor(string server, string database, string user, string pass)']]]
];
