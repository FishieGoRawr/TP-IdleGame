var hierarchy =
[
    [ "Form", null, [
      [ "ProgressQuest_Client.Form1", "class_progress_quest___client_1_1_form1.html", null ]
    ] ],
    [ "ProgressQuest_Client.SqlExecutor", "class_progress_quest___client_1_1_sql_executor.html", null ],
    [ "ProgressQuest_Client.SqlPQ", "class_progress_quest___client_1_1_sql_p_q.html", null ]
];